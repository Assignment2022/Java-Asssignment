      TNT Digital - Back-End Software Developer Assessment

 API Aggregation Service

      This project is to build an aggregation service for consolidating the interface with
      3 different external APIs into a single endpoint.Each APIs accepts a query parameter
      that can accept multiple queries.

IDE USED: IntelliJ.

TECHNOLOGIES USED:SpringBoot,MySql.
       
DEPENDENCIES ADDED: Lombok , MySql Driver, Spring Data JPA,Spring Web.

1. Create a java project in IntelliJ. Created Controller, Service and Repository classes.
2. Create a database as product_db using MySql Workbench
3. Run the application in localhost 8080 port.The following API requests will give the 
   following result
    
    1.Shipment API-  GET-http://localhost:8080/shipments?id=109347263,123456891
      
        This will return a list of product that correspond to the given id that is send 
        through the url.

    2.Track API- GET-http://localhost:8080/track?id=109347263,123456891

        This will return the status of the corresponding ids that is send through the url.
    3.Pricing API-GET- http://localhost:8080/pricing?countryCode=CN,NL

        This will return the product price in that country when we send the country code 
        in the the url.
    4.Aggregation API-   GET- http://localhost:8081/aggregation?pricing=NL,CN&track=109347263,123456891&shipments=109347263,123456891

        This is the consolidation of above 3 APIs.
Result:

    1.Shipment API

        {

            "109347263": [
            "box",
            "box",
            "pallet"
            ],
            "123456891": [
            "envelope"
            ]

        }
    2.Track API
        {

        "109347263": "NEW",

       "123456891": "COLLECTING"
       }
    3.Pricing API
        {
            "CN": 20.503467806384,
            "NL": 14.242090605778
        }
    4.Aggregation API
        {

    "shipments": {
        "109347263": [
            "box",
            "box",
            "pallet"
        ],
        "123456891": [
            "envelope"
        ]
    },
    "track": {
        "109347263": "NEW",
        "123456891": "COLLECTING"
    },
    "pricing": {
        "CN": 20.503467806384,
        "NL": 14.242090605778
    }
    
When the data are available it return 200 ok response else it return 503n unavailable













