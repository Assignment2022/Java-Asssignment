package com.assessment.assessment.service;

import com.assessment.assessment.entity.Product;
import com.assessment.assessment.repository.ProductRepository;
import com.assessment.assessment.vo.ProductVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ProductService {
    @Autowired
    private ProductRepository productRepository;
    public Map<String, List<String>> getShipments(List<String> id) {
        Map<String, List<String>> productMap=new HashMap<>();
        id.forEach(p -> {
            Product products = productRepository.findById(p).get();
            productMap.put(p,products.getProduct());

        });

        return productMap;
    }

    public Map<String,String> getTrack(List<String> id) {

        Map<String, String> productMap=new HashMap<>();
        id.forEach(p -> {
            Product products = productRepository.findById(p).get();
            productMap.put(p,products.getStatus());

        });

        return productMap;
    }

    public Map<String,Double> getPrice(List<String> countryCode) {

        Map<String, Double> productMap=new HashMap<>();
        countryCode.forEach(p -> {
            Double products = productRepository.findByCountryCode(p);
            productMap.put(p,products);

        });

        return productMap;
    }

    public ProductVO getAggregate(List<String> pricing, List<String> track, List<String> shipments) {
        ProductVO productVO=new ProductVO();
        Map<String, Double> productMap=new HashMap<>();
        pricing.forEach(p -> {
            Double products = productRepository.findByCountryCode(p);
            productMap.put(p,products);
            productVO.setPricing(productMap);
        });
        Map<String, String> productTrack=new HashMap<>();
        track.forEach(p -> {
            Product products = productRepository.findById(p).get();
            productTrack.put(p, products.getStatus());
            productVO.setTrack(productTrack);
        });
        Map<String, List<String>> productShipment=new HashMap<>();
        shipments.forEach(p -> {
            Product products = productRepository.findById(p).get();
            productShipment.put(p, products.getProduct());
            productVO.setShipments(productShipment);
        });

        return productVO;
    }
}
