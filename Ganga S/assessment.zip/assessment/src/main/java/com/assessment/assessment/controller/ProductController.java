package com.assessment.assessment.controller;

import com.assessment.assessment.service.ProductService;
import com.assessment.assessment.vo.ProductVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
public class ProductController {
    @Autowired
    private ProductService productService;
    @GetMapping("/shipments")
    public ResponseEntity<Map<String,List<String>>> getShipment(@RequestParam List<String> id){
        try{
        Map<String,List<String>> products=productService.getShipments(id);
        return new ResponseEntity<>(products,HttpStatus.OK);
        }catch (NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }

    }
    @GetMapping("/track")
    public ResponseEntity<Map<String,String>> getTrack(@RequestParam List<String> id){
        try{
        Map<String,String>statuses=productService.getTrack(id);
        return new ResponseEntity<>(statuses,HttpStatus.OK);
    }catch (NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }
    }
    @GetMapping("/pricing")
    public ResponseEntity<Map<String,Double>> getPrice(@RequestParam List<String> countryCode){
        try {
            Map<String, Double> statuses = productService.getPrice(countryCode);
            return new ResponseEntity<>(statuses, HttpStatus.OK);
        }catch (NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }
    }
    @GetMapping("/aggregation")
    public ResponseEntity<ProductVO> getAggregate(@RequestParam List<String> pricing, @RequestParam List<String> track,@RequestParam List<String> shipments){
       try {
           ProductVO statuses = productService.getAggregate(pricing, track, shipments);
           return new ResponseEntity<>(statuses, HttpStatus.OK);
       }catch (NoSuchElementException e){
           return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
       }
    }
}
