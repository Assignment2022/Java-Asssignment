package com.assessment.assessment.repository;

import com.assessment.assessment.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ProductRepository extends JpaRepository<Product, String> {
    //Product findByCountryCode(String p);
    @Query("SELECT price FROM  Product rs WHERE rs.countryCode = :countryCode")
    public Double findByCountryCode(String countryCode);
}



