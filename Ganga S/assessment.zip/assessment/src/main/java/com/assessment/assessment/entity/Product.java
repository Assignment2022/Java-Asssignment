package com.assessment.assessment.entity;

import com.assessment.assessment.constant.TextConverter;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.List;

@Entity
@Getter
@Setter
public class Product {
    @Id
   public String id;
    @Convert(converter = TextConverter.class)
   public List<String> product;
   public String status;
   @Column(name="country_code")
   public String countryCode;
   public Double price;
}
