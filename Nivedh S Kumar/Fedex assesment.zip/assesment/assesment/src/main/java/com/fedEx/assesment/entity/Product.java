package com.fedEx.assesment.entity;

import com.fedEx.assesment.costants.NewConverter;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.List;

@Entity
@Getter
@Setter
public class Product {
    @Id
    public String id ;
    @Convert (converter= NewConverter.class)
    private List<String> product_name;
    private String status;
    private String country_code;
    private Double price;


}
