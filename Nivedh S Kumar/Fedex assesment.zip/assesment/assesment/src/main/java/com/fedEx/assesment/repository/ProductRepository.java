package com.fedEx.assesment.repository;

import com.fedEx.assesment.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ProductRepository extends JpaRepository<Product, String> {
    //Product findByCountry_code(String e);
    @Query("SELECT price FROM  Product rs WHERE rs.country_code = :country_code")
    public Double findByCountry_code(String country_code);
}
