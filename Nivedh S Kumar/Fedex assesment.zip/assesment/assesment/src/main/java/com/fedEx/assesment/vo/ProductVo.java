package com.fedEx.assesment.vo;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
public class ProductVo {
    private Map<String, List<String>> shipments;
    private Map<String,String>track;
    private Map<String,Double>pricing;

}
