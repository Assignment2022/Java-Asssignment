package com.fedEx.assesment.service;

import com.fedEx.assesment.entity.Product;
import com.fedEx.assesment.repository.ProductRepository;
import com.fedEx.assesment.vo.ProductVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
@Transactional
public class ProductService {
    @Autowired
    private ProductRepository productRepository ;
    public Map<String, List<String>> getShipment(List<String> id) {
        Map<String, List<String>>mapProduct=new HashMap<>();
        id.forEach(e->{
            Product products=productRepository.findById(e).get();
            mapProduct.put(e,products.getProduct_name());
        });
       return mapProduct;

    }

    public Map<String, String> getTrack(List<String> id) {
        Map<String, String>mapProduct=new HashMap<>();
        id.forEach(e->{
            Product products=productRepository.findById(e).get();
            mapProduct.put(e,products.getStatus());
        });
        return mapProduct;
    }
    public Map<String, Double> getPricing(List<String> country_code)  {
        Map<String, Double>mapProduct=new HashMap<>();
        country_code.forEach(e->{
            Double products=productRepository.findByCountry_code(e);
            mapProduct.put(e,products);
        });
        return mapProduct;
    }

    public ProductVo getAggregate(List<String> pricing, List<String> track, List<String> shipments) {
     ProductVo productVo = new ProductVo();
        Map<String, Double>mapProduct=new HashMap<>();
        pricing.forEach(e->{
            Double products=productRepository.findByCountry_code(e);
            mapProduct.put(e,products);
            productVo.setPricing(mapProduct);
        });
        Map<String, String>mapTrack=new HashMap<>();
        track.forEach(e->{
            Product products=productRepository.findById(e).get();
            mapTrack.put(e,products.getStatus());
            productVo.setTrack(mapTrack);
        });
        Map<String, List<String>>mapShipment =new HashMap<>();
        shipments.forEach(e->{
            Product products=productRepository.findById(e).get();
            mapShipment.put(e,products.getProduct_name());
            productVo.setShipments(mapShipment);
        });
        return productVo;
    }
}

