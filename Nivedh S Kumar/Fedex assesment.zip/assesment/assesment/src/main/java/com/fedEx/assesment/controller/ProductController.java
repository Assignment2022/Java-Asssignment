package com.fedEx.assesment.controller;

import com.fedEx.assesment.service.ProductService;
import com.fedEx.assesment.vo.ProductVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
public class ProductController {
    @Autowired
    private ProductService productService;
    @GetMapping("/shipments")
    public ResponseEntity<Map<String, List<String>>>getShipment(@RequestParam List<String> id)
    {
        try {
        Map<String, List<String>> products = productService.getShipment(id);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }catch (NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
    }
    }
    @GetMapping("/track")
    public ResponseEntity<Map<String, String>>getTrack(@RequestParam List<String> id) {
        try {
            Map<String, String> products = productService.getTrack(id);
            return new ResponseEntity<>(products, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }
    }
    @GetMapping("/pricing")
    public ResponseEntity<Map<String, Double>>getPrice(@RequestParam List<String> country_code)
    {
        try {
        Map<String, Double> products = productService.getPricing(country_code);
        return new ResponseEntity<>(products, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }
    }
    @GetMapping("/aggregation")
    public ResponseEntity<ProductVo>getAggregate(@RequestParam List<String> pricing,@RequestParam List<String> track,@RequestParam List<String> shipments)
    {
        try {
        ProductVo products = productService.getAggregate(pricing,track,shipments);
        return new ResponseEntity<>(products, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }
    }


}
