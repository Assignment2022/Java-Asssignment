package com.fedex.productREST.ProductEntity;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.Id;

import com.fedex.productREST.config.StringListConverter;

@Entity
@Getter
@Setter
public class Product {	
	
	 @Id
    public String id;
	 @Convert(converter = StringListConverter.class)
	 private List<String> product;
	 @Column(name = "country_code")
     private String countryCode;
     private String status;
     private Double price;

}
