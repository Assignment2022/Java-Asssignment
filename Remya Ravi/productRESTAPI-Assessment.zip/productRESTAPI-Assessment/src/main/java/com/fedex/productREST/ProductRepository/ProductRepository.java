package com.fedex.productREST.ProductRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fedex.productREST.ProductEntity.Product;


public interface ProductRepository extends JpaRepository<Product, String> {
	@Query("SELECT price FROM  Product rs WHERE rs.countryCode = :countryCode")
	public Double findByCountryCode(String countryCode);
}