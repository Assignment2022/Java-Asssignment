package com.fedex.productREST.ProductController;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
 
import org.springframework.web.bind.annotation.*;

import com.fedex.productREST.ProductModel.ProductModel;
import com.fedex.productREST.ProductService.ProductService;
 
@RestController
public class ProductController {
 
    @Autowired
    private ProductService service;
        
    @GetMapping("/shipments")
    public ResponseEntity< Map<String,List<String>>> get(@RequestParam List<String> id) {
        try {
        	 Map<String,List<String>>  product1 = service.get(id);
            return new ResponseEntity<>(product1, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }      
    }
    
    @GetMapping("/track")
    public ResponseEntity< Map<String,String> > getTrack(@RequestParam List<String> id) {
        try {
        	 Map<String,String>  product1 = service.getTrack(id);
            return new ResponseEntity<>(product1, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }      
    }
       
    @GetMapping("/pricing")
    public ResponseEntity< Map<String,Double> > getPricing(@RequestParam List<String> countryCode) {
        try {
        	 Map<String,Double>  product1 = service.getPricing(countryCode);
            return new ResponseEntity<>(product1, HttpStatus.OK);
        } catch (NoSuchElementException e) {
        	System.out.println(e);
            return new ResponseEntity<>( HttpStatus.SERVICE_UNAVAILABLE);
        }      
    }
    
    @GetMapping("/aggregation")
    public ResponseEntity< ProductModel > getAggregation(@RequestParam List<String> pricing,@RequestParam List<String> track,@RequestParam List<String> shipments) {
        try {
        	 ProductModel  product1 = service.getAggregate(pricing,track,shipments);
            return new ResponseEntity<>(product1, HttpStatus.OK);
        } catch (NoSuchElementException e) {
        	System.out.println(e);
            return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
        }      
    }
}