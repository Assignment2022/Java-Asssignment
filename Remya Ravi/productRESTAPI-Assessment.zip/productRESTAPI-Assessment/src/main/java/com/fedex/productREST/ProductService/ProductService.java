package com.fedex.productREST.ProductService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fedex.productREST.ProductEntity.Product;
import com.fedex.productREST.ProductModel.ProductModel;
import com.fedex.productREST.ProductRepository.ProductRepository;

@Service
@Transactional
public class ProductService {

	@Autowired
	private ProductRepository repo;

	public Map<String, List<String>> get(List<String> id) {
		Map<String, List<String>> map = new HashMap<>();
		id.forEach(e -> {
			Product product1 = repo.findById(e).get();
			map.put(e, product1.getProduct());
		});
		return map;
	}

	public Map<String, String> getTrack(List<String> id) {
		Map<String, String> map = new HashMap<>();
		id.forEach(e -> {
			Product product1 = repo.findById(e).get();
			map.put(e, product1.getStatus());
		});
		return map;
	}

	public Map<String, Double> getPricing(List<String> countryCode) {
		Map<String, Double> map = new HashMap<>();
		countryCode.forEach(e -> {
			Double product1 = repo.findByCountryCode(e);
			map.put(e, product1);
		});
		return map;
	}

	public ProductModel getAggregate(List<String> pricing, List<String> track, List<String> shipments) {
		ProductModel productModel = new ProductModel();
		Map<String, Double> map = new HashMap<>();
		pricing.forEach(e -> {
			Double product1 = repo.findByCountryCode(e);
			map.put(e, product1);
			productModel.setPricing(map);
		});
		Map<String, String> trackingValues = new HashMap<>();
		track.forEach(e -> {
			Product product1 = repo.findById(e).get();

			trackingValues.put(e, product1.getStatus());
        productModel.setTrack(trackingValues);
		});
		Map<String, List<String>> shipmentValues = new HashMap<>();
		shipments.forEach(e -> {
			Product product1 = repo.findById(e).get();

			shipmentValues.put(e, product1.getProduct());
        productModel.setShipments(shipmentValues);
		});

		return productModel;
	}

}
