package com.fedex.productREST.ProductModel;


import java.util.List;
import java.util.Map;




import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductModel {

    private  Map<String,List<String>> shipments;
    private  Map<String,String> track;
    private Map<String, Double> pricing;
}
