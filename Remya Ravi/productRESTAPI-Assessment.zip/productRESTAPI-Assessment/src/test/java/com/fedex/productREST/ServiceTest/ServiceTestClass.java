package com.fedex.productREST.ServiceTest;

public class ServiceTestClass {

}
