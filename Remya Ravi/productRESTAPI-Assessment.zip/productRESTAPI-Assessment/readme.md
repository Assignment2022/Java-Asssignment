TNT Digital - Back-End Software Developer Assessment

API Aggregation Service


This is a spring boot project with spring boot crud application. This project has implemented only GET methods in 3 different APIs. APIs accepts a query parameter which can accept multiple queries. 


Technologies used:

•	Spring Boot

•	MySQL


IDE used:

•	STS


API Signatures:

Here I have run this application in localhost and 8081 port. We can change the port as you wish.

1)	GET-http://localhost:8081/shipments?id=109347263,123456891

This API will give details of the Products like name of all the products, that we send the id in the URL. Here we provide the ids as RequestParam. 

2)	GET-http://localhost:8081/track?id=109347263,123456891

This API will give details of the Products tracking status, that we send the id in the URL. Here we provide the ids as RequestParam.

3)	GET- http://localhost:8081/pricing?countryCode=CN,NL

This API will give details of the Products price, that we send the country code in the URL. Here we provide the country code as RequestParam.

4)	GET- http://localhost:8081/aggregation?pricing=NL,CN&track=109347263,123456891&shipments=109347263,123456891

This API will give full details of the Products like price, tracking status and the name of products, that we send the ids and country code in the URL respectively. Here we provide the ids and the country code as RequestParam.
Let’s test the API


Import project to IDE

First you must clone the project from the GitHub repository and then open the project using STS as below.

•	Import -> Existing maven project -> select your project 


Create the Database

Create a database as product_db in your MySQL workbench.

 
Application.properties will be like this:

server.port=8081

spring.jpa.hibernate.ddl-auto=none

spring.datasource.url=jdbc:mysql://localhost:3306/product_db

spring.datasource.username=root

spring.datasource.password=root

 
Run your project

You can test all the routes of the API using postman. Here I have included all the screen shots of API calls using postman.

1)The Shipment API

{

    "109347263": [
        "box",
        "box",
        "pallet"
    ],
    "123456891": [
        "envelope"
    ]
    
}
 
2) The Track API
 
 {
 
    "109347263": "NEW",
    
    "123456891": "COLLECTING"
}

3) The Pricing API

{

    "CN": 20.503467806384,
    "NL": 14.242090605778

}
 
4) The Aggregation API
 
 {
 
    "shipments": {
        "109347263": [
            "box",
            "box",
            "pallet"
        ],
        "123456891": [
            "envelope"
        ]
    },
    "track": {
        "109347263": "NEW",
        "123456891": "COLLECTING"
    },
    "pricing": {
        "CN": 20.503467806384,
        "NL": 14.242090605778
    }
    
}

   
 The negative scenario:
 
503 Unavailable if that id is not available in the data base.
 

	
Thank you






